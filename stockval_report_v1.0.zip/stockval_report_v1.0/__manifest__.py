{
    'name': 'stock_valuation report',
    'version': 'v1.0',
    'category': 'stock reports',
    'author': 'GBA Tecnologias',
    'website': 'www.gba.com.mx',
    'summary': """
      this module is to get stock value report with differents fields""",
    'depends': [
        'base', 'stock',
    ],
    'data': [
        'views/stock_valuation_report.xml',
        'report/stock_valuation_qweb_report.xml'
    ],
    'installable': True,
}